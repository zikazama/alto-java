package com.example.ewallet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EWalletApplicationTests {

	@Test
	void contextLoads() {
	}

}
