package com.fintech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FintechAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
